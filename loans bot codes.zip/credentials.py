username = ""  # username of reddit account
password = ""  # password of reddit account
client_id = ""  # client id of reddit app
client_secret = ""  # client secret of reddit app
user_agent = "Reddit bot for bidding"


mongo_uri = ""
mongo_dbname = "reddit"
mongo_collection = "transactions"
subreddit_name = "rktestingbtot"  # subreddit name
